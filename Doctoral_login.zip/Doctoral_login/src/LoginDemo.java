import java.util.Scanner;

import javax.swing.JFrame;
public class LoginDemo {
	public static void main(String[] args) {
		GUI go = new GUI();
		go.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		go.setSize(300, 150);
		go.setVisible(true);
	}

}
